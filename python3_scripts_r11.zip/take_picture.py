import android

droid = android.Android()
droid.cameraInteractiveCapturePicture('/mnt/sdcard/py4a_example.jpg')
